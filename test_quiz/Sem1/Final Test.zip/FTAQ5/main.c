//	Developed by LIU Tianyi 15102892d

#include "stm32f10x.h"                  // Device header

int led_state = 0;
char info_1[32] = "-ON-";
char info_2[32] = "-OFF-";
int loc = 0;
int main_state = 0;
unsigned char ch = '\0';
int state_2 = 0;
void init_pin()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStr;
	GPIO_InitStr.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4;
	GPIO_InitStr.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStr.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStr);
	
	GPIO_InitStr.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStr.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStr.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOB, &GPIO_InitStr);
}


void timer_init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	TIM_TimeBaseInitTypeDef timerInitStr;
	timerInitStr.TIM_Prescaler = 18000 - 1;
	timerInitStr.TIM_CounterMode = TIM_CounterMode_Up;
	timerInitStr.TIM_Period = 4000 - 1;
	timerInitStr.TIM_ClockDivision = TIM_CKD_DIV1;
	timerInitStr.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &timerInitStr);
	TIM_Cmd(TIM2, ENABLE);
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	NVIC_EnableIRQ(TIM2_IRQn);
}

void usart2_init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStr;
	GPIO_InitStr.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStr.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStr.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStr);
	
	GPIO_InitStr.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStr.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStr);
	
	USART_InitTypeDef USART_InitStr;
	USART_InitStr.USART_BaudRate = 9600;
	USART_InitStr.USART_WordLength = USART_WordLength_8b;
	USART_InitStr.USART_StopBits = USART_StopBits_1;
	USART_InitStr.USART_Parity = USART_Parity_No;
	USART_InitStr.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStr.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStr);
	USART_Cmd(USART2, ENABLE);
}

void usart2_int_init()
{
	NVIC_InitTypeDef NVIC_InitStr;
	USART_ITConfig(USART2, USART_IT_TC, ENABLE);
	NVIC_InitStr.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStr.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStr.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStr.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStr);

	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	NVIC_InitStr.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStr.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStr.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStr.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStr);
}


void exti_init()
{
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource0);
	EXTI_InitTypeDef EXTI_InitStr;
	EXTI_InitStr.EXTI_Line = EXTI_Line0;
	EXTI_InitStr.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStr.EXTI_LineCmd = ENABLE;
	EXTI_InitStr.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_Init(&EXTI_InitStr);
	NVIC_InitTypeDef NVIC_InitStr;
	NVIC_InitStr.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStr.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStr.NVIC_IRQChannelPreemptionPriority = 0x02;
	NVIC_Init(&NVIC_InitStr);
}

void EXTI0_IRQHandler()
{
	if (EXTI_GetITStatus(EXTI_Line0) != RESET)
	{
		if (main_state == 0)
			main_state = 1;
		else if (main_state == 1)
			main_state = 0;
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
}

void USART2_IRQHandler()
{
	if (USART_GetITStatus(USART2, USART_IT_TC) != RESET)
	{
		if (state_2 == 1)
		{
			if (main_state == 1 & info_1[loc] != '\0')
			{
				USART_SendData(USART2, info_1[loc]);
				loc++;
			}
			else if (info_1[loc] == '\0')
			{	
				loc = 0;
				state_2 = 0;
			}
			if (main_state == 2 & info_2[loc] != '\0')
			{
				USART_SendData(USART2, info_2[loc]);
				loc++;
			}
			else if (info_2[loc] == '\0')
			{	
				loc = 0;
				state_2 = 0;
			}
		}
		else
			USART_SendData(USART2, '\0');
		
		USART_ClearITPendingBit(USART2, USART_IT_TC);
	}
	
	
	if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{
		ch = (unsigned char) USART_ReceiveData(USART2);
		if (main_state == 0 && ch == 'a')
		{
			main_state = 2;
			loc = 0;
			ch = '\0';
		}
		else if (main_state == 2 && ch == 'x')
		{	
			main_state = 0;
			loc = 0;
			ch = '\0';
		}
		USART_SendData(USART2, '\0');
	}
}
	
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2,TIM_IT_Update) != RESET)
	{
		led_state ^= 0x01;
		state_2 = 1;
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
}

int main()
{
	init_pin();
	timer_init();
	usart2_init();
	usart2_int_init();
	exti_init();
	
	while(1)
	{
		if (main_state == 0)
		{
			if (!led_state)
			{
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);			
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);					
			}
			else
			{
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);			
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);			
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);			
			}	
		}
		else if (main_state == 1)
		{
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET);			
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
		}
		else if (main_state == 2)
		{
				GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);			
				GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);	
				GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
		}
	}
}

