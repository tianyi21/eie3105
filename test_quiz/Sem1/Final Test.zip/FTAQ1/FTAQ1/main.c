/*
 * FTAQ1.c
 *
 * Created: 12/4/2018 2:05:10 PM
 * Author : 15102892d LIU Tianyi
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

unsigned int state = 0;

void pin_init()
{
	DDRB = (1<<2) | (1<<3) | (1<<4) | (1<<5);
	PORTB = 0x00;
}

void timer_init()
{
	OCR1AH = 0x3D;
	OCR1AL = 0x08;
	TCCR1B = (1<<CS12) | (1<<CS10) | (1<<WGM12);
	TIMSK1 = (1<<OCIE1A);
}

int main(void)
{
    pin_init();
	timer_init();
	sei();
    while (1) 
    {
		if (!state)
			PORTB = (1<<2) | (1<<3);
		else
			PORTB = (1<<4) | (1<<5);
    }
}

ISR (TIMER1_COMPA_vect)
{
	state ^= 0x01;
}

