/*
 * FTAQ3.c
 *
 * Created: 12/4/2018 2:17:46 PM
 * Author : 15102892d LIU Tianyi
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

const unsigned char info[32] = "-AA-";
unsigned int loc = 0;
unsigned int read_loc = 0;
unsigned char ch = '\0';
unsigned int state = 0;
unsigned int tim_state = 0;

void timer_init()
{
	OCR1AH = 0x3D;
	OCR1AL = 0x08;
	TCCR1B = (1<<CS12) | (1<<CS10) | (1<<WGM12);
	TIMSK1 = (1<<OCIE1A);
}

void usart0_init()
{
	UCSR0B = (1<<TXEN0) | (1<<RXEN0) | (1<<UDRIE0) | (1<<RXCIE0); //Send, Write, Int
	UCSR0C = (1<<UCSZ00) | (1<<UCSZ01); // Char = 8
	UBRR0L = 0x67; // BR = 9600
}

int main(void)
{
    usart0_init();
	timer_init();
	sei();
    while (1) 
    {
		;
    }
}

ISR (USART_RX_vect)
{
	ch = UDR0;
	if (!state)
	{
		if (read_loc == 0 && ch == 'a')
			read_loc++;
		else if (read_loc == 1 && ch == 'a')
		{	
			state ^= 0x01;
			read_loc = 0;
			TCCR1B = 0x00;
			TCNT1H = 0x00;
			TCNT1L = 0x00;
			OCR1AH = 0x1E;
			OCR1AL = 0x84;
			TCCR1B = (1<<CS12) | (1<<CS10) | (1<<WGM12);
		}
		
	}
	if (state)
	{
		if (read_loc == 0 && ch == 'x')
			read_loc++;
		else if (read_loc == 1 && ch == 'x')
		{
			state ^= 0x01;
			read_loc = 0;
			TCCR1B = 0x00;
			TCNT1H = 0x00;
			TCNT1L = 0x00;
			OCR1AH = 0x3D;
			OCR1AL = 0x08;
			TCCR1B = (1<<CS12) | (1<<CS10) | (1<<WGM12);
		}
	}
}

ISR (USART_UDRE_vect)
{
	if (tim_state)
	{	
		if (info[loc] != '\0')
		{	
			UDR0 = info[loc];
			loc++;
		}
		else if (info[loc] == '\0')
		{
			loc = 0;
			tim_state = 0;
		}
	}
}

ISR (TIMER1_COMPA_vect)
{
	tim_state = 1;
}